﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.SharePoint.Client;

namespace Core.ListTemplateReplacement
{
    class Program
    {
        static void Main(string[] args)
        {
        }

        private static void ReplaceList(ClientContext clientContext, ListCollection listCollection, List listToBeReplaced)
        {

        }

        private static List CreateReplacementList(ClientContext clientContext, ListCollection lists, List listToBeReplaced)
        {
            return null;
        }

        private static void SetListSettings(ClientContext clientContext, List listToBeReplaced, List newList)
        {

        }


        private static void SetContentTypes(ClientContext clientContext, List listToBeReplaced, List newList)
        {

        }

        private static void AddViews(ClientContext clientContext, List listToBeReplaced, List newList)
        {

        }

        private static void RemoveViews(ClientContext clientContext, List listToBeReplaced, List newList)
        {

        }

        private static void MigrateContent(ClientContext clientContext, List listToBeReplaced, List newList)
        {

        }

        private static ViewType GetViewType(string viewType)
        {
            switch (viewType)
            {
                case "HTML":
                    return ViewType.Html;
                case "GRID":
                    return ViewType.Grid;
                case "CALENDAR":
                    return ViewType.Calendar;
                case "RECURRENCE":
                    return ViewType.Recurrence;
                case "CHART":
                    return ViewType.Chart;
                case "GANTT":
                    return ViewType.Gantt;
                default:
                    return ViewType.None;
            }
        }
    }
}
