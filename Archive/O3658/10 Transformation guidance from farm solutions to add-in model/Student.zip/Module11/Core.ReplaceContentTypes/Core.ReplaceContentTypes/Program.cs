﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace Core.ReplaceContentTypes
{
    class Program
    {
        static void Main(string[] args)
        {            

        }


        private static void CreateContentType(ClientContext cc, Web web)
        {
            
        }


        private static void CreateSiteColumn(ClientContext cc, Web web)
        {
            
        }

        private static void AddSiteColumnToContentType(ClientContext cc, Web web)
        {
            
        }


        private static void ReplaceContentType(ClientContext cc, Web web)
        {
            
        }


        private static ContentType GetContentTypeByName(ClientContext cc, Web web, string name)
        {
            
        }


    }



}
