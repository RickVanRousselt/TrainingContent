# Replacing Content Types #

### Summary ###

This sample shows how you can replace an existing content type with a new one.

It is based on Vesa Juvonen's [Core.CreateContentTypes](https://github.com/marcgrabow/PnP/tree/master/Samples/Core.CreateContentTypes/Core.CreateContentTypes) solution.

### Applies to ###
-  Office 365 Multi Tenant (MT)
-  Office 365 Dedicated (D)
-  SharePoint 2013 on-premises

### Solution ###
Solution | Author(s)
---------|----------
Core.ReplaceContentTypes | Marc Grabow 

### Version history ###
Version  | Date | Comments
---------| -----| --------
1.0  | December 31th 2014 | Initial release

### Disclaimer ###
**THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.**

