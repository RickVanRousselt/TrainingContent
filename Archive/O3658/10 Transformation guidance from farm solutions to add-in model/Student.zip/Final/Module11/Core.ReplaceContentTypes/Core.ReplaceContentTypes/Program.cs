﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace Core.ReplaceContentTypes
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var clientContext = new ClientContext("http://w15-sp/sites/ftclab"))
            {
                // Load reference to content type collection
                Web web = clientContext.Web;

                // Ensure that we have the initial config available
                CreateContentType(clientContext, web);
                CreateSiteColumn(clientContext, web);
                AddSiteColumnToContentType(clientContext, web);

                // Now replace the old with the new content type
                ReplaceContentType(clientContext, web);
            }

        }


        private static void CreateContentType(ClientContext cc, Web web)
        {
            // The new content type will be created with this name
            const string contentTypeName = "ContosoDocumentByCSOM";

            // Check if the content type does not exist yet
            var contentType = GetContentTypeByName(cc, web, contentTypeName);

            // Content type exists already, no further action required
            if (contentType != null) return;

            // Create a Content Type Information object
            ContentTypeCreationInformation newCt = new ContentTypeCreationInformation();
            // Set the name for the content type
            newCt.Name = "ContosoDocumentByCSOM";
            //Inherit from oob document - 0x0101 and assign 
            newCt.Id = "0x0101009189AB5D3D2647B580F011DA2F356FB2";
            // Set content type to be avaialble from specific group
            newCt.Group = "Contoso Content Types";
            // Create the content type
            ContentType myContentType = web.ContentTypes.Add(newCt);
            cc.ExecuteQuery();
        }


        private static void CreateSiteColumn(ClientContext cc, Web web)
        {
            // The new field name
            const string fieldName = "ContosoStringCSOM";

            // Load the list of site columns
            FieldCollection fields = web.Fields;
            cc.Load(fields);
            cc.ExecuteQuery();

            // Check existing fields
            var fieldExists = fields.Any(f => f.InternalName == fieldName);

            // Site column exists already, no further action required
            if (fieldExists) return;

            // Otherwise create the new field
            string FieldAsXML = @"<Field ID='{CB8E24F6-E1EE-4482-877B-19A51B4BE319}' 
                                        Name='" + fieldName + @"' 
                                        DisplayName='Contoso String by CSOM' 
                                        Type='Text' 
                                        Hidden='False' 
                                        Group='Contoso Site Columns' 
                                        Description='Contoso Text Field' />";
            Field fld = fields.AddFieldAsXml(FieldAsXML, true, AddFieldOptions.DefaultValue);
            cc.ExecuteQuery();
        }

        private static void AddSiteColumnToContentType(ClientContext cc, Web web)
        {
            // The new content type will be created with this name
            const string contentTypeName = "ContosoDocumentByCSOM";
            // The new field name
            const string fieldName = "ContosoStringCSOM";

            // Try to load the new content type
            var contentType = GetContentTypeByName(cc, web, contentTypeName);
            if (contentType == null) return; // not found

            // Load field links to content type
            cc.Load(contentType.FieldLinks);
            cc.ExecuteQuery();

            // Try to load the new field
            Field fld = web.Fields.GetByInternalNameOrTitle(fieldName);
            cc.Load(fld);
            cc.ExecuteQuery();

            // Try to load the content type/site column connection
            var hasFieldConnected = contentType.FieldLinks.Any(f => f.Name == fieldName);

            // Reference exists already, no further action required
            if (hasFieldConnected) return;

            // Reference does not exist yet - create the connection
            FieldLinkCreationInformation link = new FieldLinkCreationInformation();
            link.Field = fld;
            contentType.FieldLinks.Add(link);
            contentType.Update(true);
            cc.ExecuteQuery();
        }


        private static void ReplaceContentType(ClientContext cc, Web web)
        {
            // The old content type (0x010100C32DDAB6381C44868DCD5ADC4A5307D6001D104C6E9F5EA74FBDFDC3C018A02D56)
            const string oldContentTypeId = "0x010100C32DDAB6381C44868DCD5ADC4A5307D6";
            // The new content type name
            const string newContentTypeName = "ContosoDocumentByCSOM";

            // Get content type and list
            ContentType newContentType = GetContentTypeByName(cc, web, newContentTypeName);
            ListCollection lists = web.Lists;
            // Load all data required
            cc.Load(newContentType);
            cc.Load(lists,
                    l => l.Include(list => list.ContentTypes));
            cc.ExecuteQuery();
            var listsWithContentType = new List<List>();
            foreach (List list in lists)
            {
                bool hasOldContentType = list.ContentTypes.Any(c => c.StringId.StartsWith(oldContentTypeId));
                if (hasOldContentType)
                {
                    listsWithContentType.Add(list);
                }
            }
            foreach (List list in listsWithContentType)
	        {
                // Check if the new content type is already attached to the library
                var listHasContentTypeAttached = list.ContentTypes.Any(c => c.Name == newContentTypeName);
                if (!listHasContentTypeAttached)
                {
                    // Attach content type to list
                    list.ContentTypes.AddExistingContentType(newContentType);
                    cc.ExecuteQuery();
                }
                // Lost all list items
                CamlQuery query = CamlQuery.CreateAllItemsQuery();
                ListItemCollection items = list.GetItems(query);
                cc.Load(items);
                cc.ExecuteQuery();

                // For each list item check if it is set to the old content type, update to new one if required
                foreach (ListItem listItem in items)
                {
                    // Currently assigned content type to this item
                    var currentContentTypeId = listItem["ContentTypeId"] + "";
                    var isOldContentTypeAssigned = currentContentTypeId.StartsWith(oldContentTypeId);

                    // This item is not assigned to the old content type - skip to next one
                    if (!isOldContentTypeAssigned) continue;

                    // Update to new content type
                    listItem["ContentTypeId"] = newContentType.StringId; // newContentTypeId;
                    listItem.Update();
                }
                // Submit all changes
                cc.ExecuteQuery();
            }
        }


        private static ContentType GetContentTypeByName(ClientContext cc, Web web, string name)
        {
            ContentTypeCollection contentTypes = web.ContentTypes;
            cc.Load(contentTypes);
            cc.ExecuteQuery();
            return contentTypes.FirstOrDefault(o => o.Name == name);
        }


    }



}
