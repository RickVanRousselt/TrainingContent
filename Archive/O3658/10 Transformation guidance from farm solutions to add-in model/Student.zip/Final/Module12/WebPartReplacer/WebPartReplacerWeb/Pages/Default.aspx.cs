﻿using System;
using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Client.WebParts;

namespace WebPartReplacerWeb
{
    public partial class Default : System.Web.UI.Page
    {
        // Title of the OLD web part to be replaced by an app part
        private const string oldWebPartTitle = "Contoso.Intranet - WelcomeWebPart";

        // XML for the App Part            
        private const string appPartXml = @"<webParts>
  <webPart xmlns=""http://schemas.microsoft.com/WebPart/v3"">
    <metaData>
      <type name=""Microsoft.SharePoint.WebPartPages.ClientWebPart, Microsoft.SharePoint, Version=15.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c"" />
      <importErrorMessage>Cannot import this Web Part.</importErrorMessage>
    </metaData>
    <data>
      <properties>
        <property name=""TitleIconImageUrl"" type=""string"" />
        <property name=""Direction"" type=""direction"">NotSet</property>
        <property name=""ExportMode"" type=""exportmode"">All</property>
        <property name=""HelpUrl"" type=""string"" />
        <property name=""Hidden"" type=""bool"">False</property>
        <property name=""Description"" type=""string"">WelcomeAppPart Description</property>
        <property name=""FeatureId"" type=""System.Guid, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089"">0b846986-3474-4f1a-93cf-b7817ef057f9</property>
        <property name=""CatalogIconImageUrl"" type=""string"" />
        <property name=""Title"" type=""string"">WelcomeAppPart Title</property>
        <property name=""AllowHide"" type=""bool"">True</property>
        <property name=""ProductWebId"" type=""System.Guid, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089"">717c00a1-08ea-41a5-a2b7-4c8f9c1ce770</property>
        <property name=""AllowZoneChange"" type=""bool"">True</property>
        <property name=""TitleUrl"" type=""string"" />
        <property name=""ChromeType"" type=""chrometype"">Default</property>
        <property name=""AllowConnect"" type=""bool"">True</property>
        <property name=""Width"" type=""unit"" />
        <property name=""Height"" type=""unit"" />
        <property name=""WebPartName"" type=""string"">WelcomeAppPart</property>
        <property name=""HelpMode"" type=""helpmode"">Navigate</property>
        <property name=""AllowEdit"" type=""bool"">True</property>
        <property name=""AllowMinimize"" type=""bool"">True</property>
        <property name=""ProductId"" type=""System.Guid, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089"">0b846986-3474-4f1a-93cf-b7817ef057f8</property>
        <property name=""AllowClose"" type=""bool"">True</property>
        <property name=""ChromeState"" type=""chromestate"">Normal</property>
      </properties>
    </data>
  </webPart>
</webParts>";

        protected void Page_PreInit(object sender, EventArgs e)
        {
            Uri redirectUrl;
            switch (SharePointContextProvider.CheckRedirectionStatus(Context, out redirectUrl))
            {
                case RedirectionStatus.Ok:
                    return;
                case RedirectionStatus.ShouldRedirect:
                    Response.Redirect(redirectUrl.AbsoluteUri, endResponse: true);
                    break;
                case RedirectionStatus.CanNotRedirect:
                    Response.Write("An error occurred while processing your request.");
                    Response.End();
                    break;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            // define initial script, needed to render the chrome control
            string script = @"
            function chromeLoaded() {
                $('body').show();
            }

            //function callback to render chrome after SP.UI.Controls.js loads
            function renderSPChrome() {
                //Set the chrome options for launching Help, Account, and Contact pages
                var options = {
                    'appTitle': document.title,
                    'onCssLoaded': 'chromeLoaded()'
                };

                //Load the Chrome Control in the divSPChrome element of the page
                var chromeNavigation = new SP.UI.Controls.Navigation('divSPChrome', options);
                chromeNavigation.setVisible(true);
            }";

            //register script in page
            Page.ClientScript.RegisterClientScriptBlock(typeof(Default), "BasePageScript", script, true);
        }

        protected void ReplaceWebPartsWithAppParts_Click(object sender, EventArgs e)
        {
            var spContext = SharePointContextProvider.Current.GetSharePointContext(Context);
            using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                Web web = clientContext.Web;
                // Get a few properties from the web
                clientContext.Load(web,
                                    w => w.ServerRelativeUrl,
                                    w => w.AllProperties);
                clientContext.ExecuteQuery();
                //Read the pages library name from the web properties
                var pagesListName = web.AllProperties["__pageslistname"] as string;

                var list = web.Lists.GetByTitle(pagesListName);
                var items = list.GetItems(CamlQuery.CreateAllItemsQuery());
                //make sure to include the File on each Item fetched
                clientContext.Load(items,
                                    i => i.Include(
                                            item => item.File));
                clientContext.ExecuteQuery();

                // Iterate through all available pages in the pages list
                foreach (var item in items)
                {
                    FindWebPartForReplacement(item, clientContext, web);
                }
            }
        }
//
//        private string GenerateAppPartXml(ClientContext clientContext, Web web)
//        {
//            FeatureCollection features = web.Features;
//            clientContext.Load(features, f => f.Include(feature => feature.DefinitionId, feature => feature.DisplayName));
//            clientContext.ExecuteQuery();
//
//            foreach (Feature feature in features)
//            {
//                Console.WriteLine(feature.DisplayName +": " + feature.DefinitionId);
//            }
//
//            return string.Empty;
//        }

        private static void FindWebPartForReplacement(ListItem item, ClientContext clientContext, Web web)
        {
            File page = item.File;
            // Requires Full Control permissions on the Web
            LimitedWebPartManager webPartManager = page.GetLimitedWebPartManager(PersonalizationScope.Shared);
            clientContext.Load(webPartManager,
                                wpm => wpm.WebParts,
                                wpm => wpm.WebParts.Include(
                                                    wp => wp.WebPart.Title));
            clientContext.ExecuteQuery();

            foreach (var oldWebPartDefinition in webPartManager.WebParts)
            {
                var oldWebPart = oldWebPartDefinition.WebPart;
                // only modify if we find the old web part
                if (oldWebPart.Title != oldWebPartTitle) continue;

                ReplaceWebPart(web, item, webPartManager, oldWebPartDefinition, clientContext, page);
            }
        }

        private static void ReplaceWebPart(Web web, ListItem item, LimitedWebPartManager webPartManager,
            WebPartDefinition oldWebPartDefinition, ClientContext clientContext, File page)
        {
            // Check out the page for editing
            PublishingHelper.CheckOutFile(web, item);
            // transform the xml into a web part definition
            var definition = webPartManager.ImportWebPart(appPartXml);
            webPartManager.AddWebPart(definition.WebPart, "RightColumn", 0);

            // Now delete the old web part from the page
            oldWebPartDefinition.DeleteWebPart();
            clientContext.Load(page,
                                p => p.CheckOutType,
                                p => p.Level);

            clientContext.ExecuteQuery();
            // check in all the changes
            PublishingHelper.CheckInPublishAndApproveFile(page);
        }
    }
}