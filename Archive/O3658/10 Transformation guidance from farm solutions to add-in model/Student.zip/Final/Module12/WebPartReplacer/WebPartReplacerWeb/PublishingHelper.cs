﻿using System;
using Microsoft.SharePoint.Client;

namespace WebPartReplacerWeb
{
    public class PublishingHelper
    {
        public static void CheckInPublishAndApproveFile(File uploadFile)
        {
            if (uploadFile.CheckOutType != CheckOutType.None)
            {
                uploadFile.CheckIn("Updating branding", CheckinType.MajorCheckIn);
            }

            if (uploadFile.Level == FileLevel.Draft)
            {
                uploadFile.Publish("Updating branding");
            }

            uploadFile.Context.Load(uploadFile, f => f.ListItemAllFields);
            uploadFile.Context.ExecuteQuery();

            if (uploadFile.ListItemAllFields["_ModerationStatus"].ToString() == "2") // SPModerationStatusType.Pending
            {
                uploadFile.Approve("Updating branding");
                uploadFile.Context.ExecuteQuery();
            }
        }

        public static void CheckOutFile(Web web, string fileName, string filePath)
        {
            var fileUrl = String.Concat(filePath, "/", fileName);
            var temp = web.GetFileByServerRelativeUrl(fileUrl);

            CheckOutFile(web, temp);
        }

        public static void CheckOutFile(Web web, ListItem item)
        {
            var file = item.File;
            CheckOutFile(web, file);
        }

        private static void CheckOutFile(Web web, File temp)
        {
            web.Context.Load(temp, f => f.Exists);
            web.Context.ExecuteQuery();

            if (temp.Exists)
            {
                web.Context.Load(temp, f => f.CheckOutType);
                web.Context.ExecuteQuery();

                if (temp.CheckOutType != CheckOutType.None)
                {
                    temp.UndoCheckOut();
                }

                temp.CheckOut();
                web.Context.ExecuteQuery();
            }
        }
    }
}