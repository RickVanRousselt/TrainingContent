﻿namespace ModuleReplacement
{
    public class MasterPageGalleryFile
    {
        public string File { get; set; }
        public string Replaces { get; set; }
        public string ContentTypeId { get; set; }
    }

    public class LayoutFile : MasterPageGalleryFile
    {
        public string Title { get; set; }
        public string AssociatedContentTypeName { get; set; }
        public string AssociatedContentTypeId { get; set; }
        public bool DefaultLayout { get; set; }
    }
}